/* M.O.R.C. icon set. 24px grid, 1.5 stroke, inherits currentColor.
   Usage: MORC_ICON('heart') or MORC_ICON('heart', 'extra-class'). */
(function () {
  const S = (d, extra) => `<svg class="ic${extra ? ' ' + extra : ''}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${d}</svg>`;
  const P = {
    search: '<circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/>',
    bag: '<path d="M5 8h14l-1 12H6L5 8z"/><path d="M9 8V6.5a3 3 0 016 0V8"/>',
    heart: '<path d="M12 20.3s-7.8-4.6-7.8-10.1A4.4 4.4 0 0112 7.6a4.4 4.4 0 017.8 2.6c0 5.5-7.8 10.1-7.8 10.1z"/>',
    heartFill: '<path fill="currentColor" stroke="none" d="M12 20.3s-7.8-4.6-7.8-10.1A4.4 4.4 0 0112 7.6a4.4 4.4 0 017.8 2.6c0 5.5-7.8 10.1-7.8 10.1z"/>',
    bookmark: '<path d="M6.5 4h11v16.5L12 16.5l-5.5 4V4z"/>',
    bookmarkFill: '<path fill="currentColor" d="M6.5 4h11v16.5L12 16.5l-5.5 4V4z"/>',
    send: '<path d="M21 3.5L10.2 13.8"/><path d="M21 3.5l-6.6 17-4.2-6.7-6.7-4.2 17.5-6.1z"/>',
    share: '<path d="M12 3v12"/><path d="M8 7l4-4 4 4"/><path d="M6 11H5v9h14v-9h-1"/>',
    bolt: '<path d="M13 2.5L5 13.5h6l-1 8 8-11h-6l1-8z"/>',
    receipt: '<path d="M6 3h12v18l-2-1.5-2 1.5-2-1.5-2 1.5-2-1.5L6 21V3z"/><path d="M9 8h6M9 12h6M9 16h3"/>',
    whatsapp: '<path d="M4.5 19.5l1.2-3.7A8 8 0 1112 20a8 8 0 01-3.8-1l-3.7.5z"/><path d="M9.2 8.6c.2-.5.5-.5.8-.5h.5c.2 0 .4.1.5.4l.7 1.6c.1.2 0 .5-.1.6l-.5.6c-.1.2-.1.4 0 .5.6 1 1.4 1.8 2.4 2.3.2.1.4.1.5-.1l.6-.7c.2-.2.4-.2.6-.1l1.6.8c.2.1.3.3.3.5 0 .9-.7 1.7-1.6 1.8-1 .1-2.6-.3-4.3-1.9-1.8-1.7-2.4-3.4-2.3-4.4 0-.6.1-1 .3-1.3z" fill="currentColor" stroke="none"/>',
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    minus: '<path d="M5 12h14"/>',
    arrow: '<path d="M4 12h15"/><path d="M13 6l6 6-6 6"/>',
    arrowUp: '<path d="M7 17L17 7"/><path d="M8 7h9v9"/>',
    truck: '<path d="M3 6h11v10H3z"/><path d="M14 9h4l3 3.5V16h-7"/><circle cx="7" cy="17.5" r="1.8"/><circle cx="17.5" cy="17.5" r="1.8"/>',
    cash: '<rect x="2.5" y="6" width="19" height="12" rx="1.5"/><circle cx="12" cy="12" r="2.8"/><path d="M6 9.5v5M18 9.5v5"/>',
    shield: '<path d="M12 3l7.5 3v5.5c0 4.6-3.2 8.2-7.5 9.5-4.3-1.3-7.5-4.9-7.5-9.5V6L12 3z"/><path d="M8.8 12.2l2.2 2.2 4.3-4.6"/>',
    swap: '<path d="M4 8h13"/><path d="M14 4.5L17.5 8 14 11.5"/><path d="M20 16H7"/><path d="M10 12.5L6.5 16l3.5 3.5"/>',
    ruler: '<path d="M3.5 15.5L15.5 3.5l5 5-12 12-5-5z"/><path d="M7 12l2 2M10 9l2 2M13 6l2 2"/>',
    star: '<path d="M12 3.5l2.6 5.4 5.9.8-4.3 4.1 1 5.8L12 16.9l-5.2 2.7 1-5.8-4.3-4.1 5.9-.8L12 3.5z"/>',
    sliders: '<path d="M4 7h9M17 7h3M4 17h3M11 17h9"/><circle cx="15" cy="7" r="2"/><circle cx="9" cy="17" r="2"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    phone: '<rect x="7" y="2.5" width="10" height="19" rx="2"/><path d="M11 18.5h2"/>',
    pin: '<path d="M12 21s-6.5-5.6-6.5-11a6.5 6.5 0 0113 0c0 5.4-6.5 11-6.5 11z"/><circle cx="12" cy="10" r="2.3"/>',
    user: '<circle cx="12" cy="8.5" r="3.8"/><path d="M4.5 20.5a7.5 7.5 0 0115 0"/>',
    mail: '<rect x="3" y="5.5" width="18" height="13" rx="1.5"/><path d="M3.5 6.5l8.5 6.5 8.5-6.5"/>',
    box: '<path d="M3.5 7.5L12 3.5l8.5 4v9L12 20.5l-8.5-4v-9z"/><path d="M3.5 7.5L12 11.5l8.5-4M12 11.5v9"/>',
    tag: '<path d="M3.5 12.5V4h8.5l8.5 8.5-8 8-9-8z"/><circle cx="8" cy="8.5" r="1.4"/>',
    clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
    spark: '<path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5L18 18M18 6l-2.5 2.5M8.5 15.5L6 18"/>',
    menu: '<path d="M4 8h16M4 16h16"/>',
    eye: '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="3"/>',
    link: '<path d="M10 14a4 4 0 005.7 0l3-3a4 4 0 00-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 00-5.7 0l-3 3a4 4 0 005.7 5.7l1-1"/>',
    lock: '<rect x="5" y="10.5" width="14" height="10" rx="1.5"/><path d="M8 10.5V7.5a4 4 0 018 0v3"/>',
    ticket: '<path d="M3 7.5h18v3a2 2 0 000 3v3H3v-3a2 2 0 000-3v-3z"/><path d="M14.5 7.5v9" stroke-dasharray="1.5 2"/>',
    camera: '<path d="M4 8h3l1.5-2.5h7L17 8h3v11H4V8z"/><circle cx="12" cy="13.2" r="3.5"/>',
    home: '<path d="M4 11l8-6.5 8 6.5V20H4v-9z"/><path d="M10 20v-5h4v5"/>',
    play: '<path d="M8 5.5v13l10.5-6.5L8 5.5z"/>',
    flame: '<path d="M12 21c-3.9 0-6.5-2.6-6.5-6.2 0-3.8 3.4-5.4 3.4-9.3 2.7 1.4 4.6 4 4.6 6.6.9-.5 1.6-1.6 1.7-2.8 1.8 1.6 3.3 3.6 3.3 5.9 0 3.4-2.6 5.8-6.5 5.8z"/>'
  };
  window.MORC_ICON = (name, extra) => S(P[name] || P.spark, extra);
  window.MORC_ICONS = P;
})();
